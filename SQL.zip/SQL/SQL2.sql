/*1) Number Function - 
	- Number Function are used for numeric calculation or mathematical calculations.
		round()
			-used for rounded to an integer and also used for round the decimal points.
		truncate()
			used to cut value after or before the decimal points.
		ceil()
			If there is any value in it it will add 1 to it.
		floor()
			-floor is opposite to ceiling.
			-floor is similar to truncate.
			it removes the decimal and it return the smallest number.
		sign()
			-check if number is +ve or -ve
			-Return the sign of given number
			-
		MOD()
			-returns the remainder
		sqrt()
			-return the non-negative square root
		power()
			-used for find out the cube root
		abs()
			-return the absolute value of interger.
			-it is always return a positive number.
		log()
			-it return natural logarithm.
		
2) Date Function
		-It return the no.od days between two dates or datetimes.
		-it stores 7 byte of storage
		-default value for the datetime is 12 AM Midnight.
		
		SYSDATE()
			-return the database server date and time.
		NOW()
			-return server date and time when statement began to excute.
		ADDDATE()
		DATEDIFF()
			- return the no.of days between two days values.
		LAST_DAY()
			-return the last day of month for a given date
		DAYNAME()
			-return the dayname for a week in a given date.
		
3) List Function
	-it will work with all datatype
	-it independent of datatype.
	Note. Any Comaparison done with null it returns null;
	eg.null value

4) Environment Function
	USER()
		-it returns system username
		
5)Group Function
	-it is also known as Aggregate Function.
	-it will operate on Multiple row at a time.
*/





/*	Number Function		*/
use cdacmumbaipgdacsep2021;
DROP TABLE IF EXISTS emp;
create table emp1
(
	empno int(5),
    ename varchar(20),
    sal float,
    hiredate date
);
insert into emp1 values
(1,'rohit',4532.33,'2019/02/15'),
(2,'virat',5055.45,'2010/11/25'),
(3,'Rahul',4999.68,'2006/05/09'),
(4,'Dhoni',7888.82,'2011/07/19');

/* number function*/
select round(sal),sal from emp1;
select round(sal,1),sal from emp1;
select round(sal,2),sal from emp1;
select round(sal,-2),sal from emp1;
select round(sal,-3),sal from emp1;
select truncate(sal,0)from emp1;
select truncate(sal,1)from emp1;
select truncate(sal,-2)from emp1;
select ceil(sal),sal from emp1;
select floor(sal),sal from emp1;						
select truncate(3.6,0),floor(3.6) from emp1;
select sign(-15)from dual;
select mod(9,5)from dual;
select sqrt(81) from dual;
select power(10,3)from dual;
select abs(-10)from dual;

/*date function*/
select sysdate() from dual;
select now() from dual;
select sysdate(),now(),sleep(10) from dual;

select adddate(sysdate(),1) from dual;
select adddate(sysdate(),2) from dual;
select adddate(sysdate(),7) from dual;
select adddate(sysdate(),-1) from dual;
select datediff(sysdate(),hiredate) from emp1;
select date_add(hiredate,interval 2 month)from emp1;
select date_add(hiredate,interval -2 month)from emp1;
select date_add(hiredate,interval 1 year)from emp1;
select last_day(hiredate) from emp1;
select dayname(sysdate())from dual;
select upper(dayname(sysdate()))from dual;
select addtime('2010-01-15 11:00:00','1')from dual;
select addtime('2010-01-15 11:00:00','1:00:00')from dual;
select addtime('2010-01-15 11:00:00','1:30:45')from dual;



/* LIST FUNCTION */
select *from emp
where comm=null; 

select (sal+comm) from emp;
select ifnull(sal,0)+ifnull(comm,0)from emp;
select greatest(sal,3000) from emp;
select least (sal,3000)from emp;

/*Environment Function*/
select user() from dual;

/* group function*/

/**sum function**/
select sum(sal) from emp;
select sum(ifnull(sal,0)) from emp;
		
/**avg function**/
select * from emp;
insert into emp values(0004,'gopal','programmer',7899,'99/10/11',null,null,10);	
select * from emp;
select avg(sal) from emp;		
select avg(ifnull(sal,0)) from emp;	/*substitute sal as 0 if null found and then find average*/
select avg(hiredate) from emp;
delete from emp where empno=0004;		/*deleted again to check avg(sal) function*/
select * from emp;

/**min function**/
select min(sal) from emp;
select min(empno) from emp;
select min(ename) from emp;			
select min(hiredate) from emp;		

/**max function**/
select max(sal) from emp;
select max(hiredate) from emp;
select max(empno) from emp;
select max(ename) from emp;

/**count function**/
insert into emp values(0004,'gopal','programmer',7899,'99/10/11',null,null,10);
select count(sal) from emp;	
select count(ifnull(sal,0)) from emp;
delete from emp where empno=0004;	
select count(*) from emp where job='manager';
select count(*) from emp where sal>2000;


/*	CASE EXPRESSION		*/
create table emp2
(
	sal int(4),
    deptno varchar(20)
);
insert into emp2 values
(1000,10),
(2000,20),
(3000,30),
(4000,40);
select case
	when deptno = 10 then 'Training'
    when deptno = 20 then 'Exports'
    when deptno = 30 then 'Sales'
    else'others'
    end A
    from emp2;





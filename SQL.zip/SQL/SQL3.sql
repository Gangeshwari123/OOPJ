create database trans;
use trans;

create table `bank_trans`
(`name` varchar(20),
`password` varchar(8),
amount varchar(10));

insert into `bank_trans`
values('yogi',123,23000),
('modi',122,790000);

select * from `bank_trans`;
start transaction;
insert bank_trans values('yogita',123,23000);
update `bank_trans` set amount = 25000
where name = "yogi";
select * from bank_trans;


select * from `bank_trans`;
insert into bank_trans
values ('swara',578,50000);
select * from `bank_trans`;
commit;
savepoint abc;
insert into bank_trans
values ('madhu',600,50550);
select * from `bank_trans`;
commit;

insert into bank_trans
values ('Dhanu',700,55550);
select * from `bank_trans`;
savepoint dc;
insert into bank_trans
values ('Swr',880,95850);

select * from `bank_trans`;

/*rollback to dc;*/

select * from `bank_trans`;
commit;
insert into bank_trans
values ('panu',120,69850);
commit;
select * from `bank_trans`;
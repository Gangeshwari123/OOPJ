create database exercise2;
use exercise2;

create table SUPPLIER
(Sno char(5),Sname varchar(10), STATUS varchar(10),City varchar(10));
desc SUPPLIER;

create table PARTS
(Pno int(2), Pname varchar(10),Color char(10), Weight float, City char(10));
desc PARTS;

create table PROJECTS
(Jno int(2), Jname char(10), City char(10));
desc PROJECTS;

create table SPP 
(Sno int(2), Pno int(2),Jno int(2));
desc SPP;

alter table SUPPLIER
modify Sno char(5);

select * from SUPPLIER;

insert into SUPPLIER(Sno)
value('S1'),('S2'),('S3');

select * from SUPPLIER;

alter table Parts
modify Pno char(5);
alter table Projects
modify Jno char(5);
insert into SUPPLIER(STATUS)
value('10'),('20'),('30');
select * from SUPPLIER;
select Sno,Sname from SUPPLIER;
insert into Parts(Pname, Color, City)
value('Amen','Pink','London'),
('Martin','Orange','Paris'),
(null,null,'USA');
select * from Parts;
select Pname , Color from Parts
where city = 'London';
insert into SUPPLIER(Sno, Sname, Status, City)
value('1','Dhanu','Not Done','London'),
('2','Swara','Not Done','London'),
('3','Pradnya','Done','London'),
('4','Arti','Done','Paris'),
('5','Pooja','Not Done','Australia');
select * from supplier;
select * from Supplier
	where City = 'London';

update Supplier
	set city = 'Athens'
		where city = 'Australia';
    
select * from supplier
	where city = 'Paris' or city = 'Athens'; 
    
insert into Projects(Jno)
value('J1'),('J2'),('J3');

delete from Parts
	where Pno in ('P1','P2','P3');
    
insert into Parts(Pno)
values ('P1'),('P2'),('P3');

delete from Parts
	where Pno between 'P1' and 'P4';
select * from Parts;
update Parts
	set Pno = 'P1'
		where City = 'London';
update Parts
	set Pno = 'P2' 
		where City = 'Paris';
update Parts
	set Pno = 'P3' 
		where City = 'USA';
select * from Parts;
update Projects
set City = 
	case 
    when Jno = 'J1' then 'London'
    when Jno = 'J2' then 'Berlin'
    when Jno = 'J3' then 'Tokya'
end;
select * from Parts;
update Parts
	set weight = 
		case
		when Pno = 'P1' then 12.5
		when Pno = 'P2' then 13.5
		when Pno = 'P3' then 14
    end;
  select weight from Parts
  where weight in(12.5,13,14); 
  select * froSm Supplier;
  
  



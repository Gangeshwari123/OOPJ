create database exercise1;
use exercise1;
create table SEMP
(EMPNO char(4), EMPNAME char(20), BASIC float, DEPTNO char(2), DEPTHEAD char(4));
create table SDEPT
(DEPTNO char(2), DEPTNAME char(15));

insert into SDEPT
values(10, 'Development'),
(20, 'Training');

insert into SEMP
values(0001,'Sunil', 6000, 10,null),
(0002,'Hiren', 8000, 20,null),
(0003,'Ali',4000, 10, 0001),
(0004,'George',6000,null,0002);
select * from SEMP;




create database practice2;
use practice2;
DROP TABLE IF EXISTS emp;
create table emp
(EMPNO int(2),ENAME char(20), SAL int(5), DEPTNO int(1), JOB char(1), MGR int(1));
desc emp;
insert into emp
values (1,'Arun',8000,1,'M',4),
(2,'Ali',7000,1,'C',1),
(3,'Kiran',3000,1,'C',1),
(4,'Jack',9000,2,'M',null),
(5,'Thomas',8000,2,'C',4);
create table dept
(DEPTNO int(1),DNAME char(5), LOC char(4));
desc dept;
insert into dept
values(1,'TRN','Bby'),
(2,'EXP','Dlh'),
(3,'MKTG','Cal');
select * from emp;
select * from dept;
alter table dept rename column DEPT to DEPTNO; 

